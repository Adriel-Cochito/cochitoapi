package br.edu.infnet.cochitoapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CochitoapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CochitoapiApplication.class, args);
	}

}
